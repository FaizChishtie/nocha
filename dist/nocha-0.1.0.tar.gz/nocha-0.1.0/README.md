# nocha v0.1.0

Use nocha to switch versions of node with nodist.

## Setup

Run ```nocha-install.bat``` and then try running ```nocha``` on your cli!

Or type ```py setup.py install``` on your cli and run ```nocha``` after.


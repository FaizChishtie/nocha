# nocha v0.1.0

Use nocha to switch versions of node with nodist.
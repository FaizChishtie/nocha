# logger

# basic logger
def log(items):
    print(items)